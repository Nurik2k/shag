﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CombinatoricsLibrary;

namespace CombinatoricsCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Combinatorics.Factorial(5));
            Console.ReadKey();
        }
    }
}
