﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CombinatoricsLibrary
{
    public static class Combinatorics
    {
        public static ulong Factorial(uint val)
        {
            ulong answer = 1;
            for (uint i = 1; i < val + 1; i++)
                answer *= i;
            return answer;
        }
    }
}
